
Augusta Sand & Gravel — Drop-in site bundle

How to use (GitHub Pages or any static host):
1) Replace your repo files with these (index.html, manifest.webmanifest, and /icons folder).
2) Commit & push.
3) On your phone: delete the old home-screen icon, open the site, and Add to Home Screen (or Install app).

Notes:
- Paths are relative (./icons/...), so it works from a subfolder like /dump-trailer-app/.
- If the icon doesn't change immediately, hard-refresh and try again, or bump the manifest link to ?v=2.
